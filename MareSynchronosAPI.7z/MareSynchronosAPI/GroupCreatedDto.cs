﻿namespace MareSynchronos.API
{
    public record GroupCreatedDto
    {
        public string GID { get; set; }
        public string Password { get; set; }
    }
}
