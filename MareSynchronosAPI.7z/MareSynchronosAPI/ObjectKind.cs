﻿namespace MareSynchronos.API
{
    public enum ObjectKind
    {
        Player = 0,
        MinionOrMount = 1,
        Companion = 2,
        Pet = 3,
    }
}
