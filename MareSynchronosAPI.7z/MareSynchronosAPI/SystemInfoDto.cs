﻿namespace MareSynchronos.API
{
    public record SystemInfoDto
    {
        public int OnlineUsers { get; set; }
    }
}
